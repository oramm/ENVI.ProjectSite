'use strict'

module.exports = require('./js')
