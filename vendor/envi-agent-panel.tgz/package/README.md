# @envi/agent-panel

Rama przebiegu React 19: kroki, czas serwera, kontakt, pytanie i ostatnia odpowiedź, przerwanie i stany końcowe. Nie pobiera danych i nie używa hooków. Wyniki i rozpatrywanie propozycji należą do systemu.

System dostarcza `AgentPanelModel`, aktualizuje `serverNow` podczas odpytywania, mapuje swoje starsze zadania, kontroluje uprawnienia i obsługuje `onCancel` (w tym potwierdzenie). `cancelled` oznacza odwołanie dostępu; nie potwierdza posprzątania komputera.

Opcjonalne `takeover: { available, pending? }` i akcja `onTakeover` udostępniają przejęcie sesji Claude. System wylicza uprawnienia i wymienia klucz; rama pokazuje przycisk tylko dla aktywnego zadania lokalnego z `available=true`. Nazwa i pełny dymek mają jednego właściciela: eksport `CLAUDE_TAKEOVER`. Stan `taken-over` opisuje rozmowę w terminalu i wyjaśnia, że „Przerwij” odcina odbiór wyniku, a pracownik zamyka także rozmowę.

`proposalCount` liczy wszystkie oddane propozycje, a `pendingCount` tylko oczekujące na decyzję — od tej drugiej liczby zależy zachęta do ich przejrzenia.

Opcjonalne `outputFiles?: { name: string; url: string }[]` zawiera zapisane przez system pliki i ich zweryfikowane adresy HTTPS (np. z odpowiedzi `POST /result-files`). Panel pokazuje sekcję „Pliki wynikowe na Dysku” także po błędzie lub przerwaniu; linki otwierają nową kartę, z informacją dla czytnika ekranu i `rel="noopener noreferrer"`. Brak pola albo pusta tablica nie zmienia widoku. Panel nie zapisuje plików i nie wywołuje Dysku.

```tsx
import { AgentPanel } from '@envi/agent-panel';
import '@envi/agent-panel/style.css';
<AgentPanel model={model} onCancel={confirmCancellation} />
```

Przypnij zmienne CSS na kontenerze gospodarza: `--envi-agent-border`, `--envi-agent-surface`, `--envi-agent-text`, `--envi-agent-muted`, `--envi-agent-accent`, `--envi-agent-on-accent`, `--envi-agent-warning`, `--envi-agent-link`. Przykład: `--envi-agent-border: var(--color-border)`. Linki plików są podkreślone; kolor bierze `--envi-agent-link`, następnie `--envi-agent-accent`, a domyślnie `#1d4ed8`. Wartości domyślne pozwalają używać ramy samodzielnie. CSS bez Tailwinda.

`npm install` buduje `dist/` przez `prepare`; `npm test` buduje i uruchamia testy funkcji i renderu. Publikowana paczka zawiera tylko `dist/`. Przy lokalnym `file:` gospodarz ustawia Vite `resolve.dedupe: ['react', 'react-dom']`. Paczka nie należy do instalacji pracownika.

Przed pierwszym `npm ci` w klonie FIDmana przygotuj lokalnie dowiązaną paczkę:

```powershell
npm --prefix C:\systems-dev\envi-agent\repo\panel ci
```

Samo `npm ci` FIDmana uruchamia `prepare` paczki `file:`, ale nie instaluje jej zależności deweloperskich; w świeżej kopii brakuje `tsc`. Powyższa komenda instaluje je i buduje `dist/`. Wydanie przypiętej wersji z gita, jak `@envi/bug-report`, pozostaje na G-EAG-3.

## Pomoc ENVI (szuflada helpdesku)

Nowe eksporty obok `AgentPanel`: `PomocDrawer`, `PomocButton`, `EnviTurbine` (znak ENVI wbudowany w paczkę, obraca się podczas pracy; wyłączony przy `prefers-reduced-motion`) oraz typy `PomocModel`, `PomocMessage`, `PomocHandlers`. Szuflada nie pobiera danych: gospodarz trzyma rozmowę i dostarcza `PomocModel` (system w trzech przypadkach, wersja, ścieżka ekranu, wiadomości, `busy`, pytania typowe dla ekranu) oraz zdarzenia `onClose`, `onAsk`, `onAction`, `onFeedback`, `onReport`. „Skąd to wiem?” pokazuje się tylko, gdy gospodarz poda `onSource`. Stopka „Na podstawie {system} {wersja}” jest przy każdej odpowiedzi poza odmowami (`refusal: true`).

```tsx
<PomocButton open={open} busy={model.busy} onClick={toggle} />   {/* w pasku, obok menu konta */}
{open && <PomocDrawer model={model} onClose={toggle} onAsk={ask} onReport={report} onFeedback={rate} />}
```

Rama jest częścią paczki: szuflada stoi `fixed` przy prawej krawędzi (poniżej 900 px szerokości okna — na całą szerokość) i po zamontowaniu ustawia na `document.body` zmienną `--envi-pomoc-drawer-width` (po zamknięciu ostatniej instancji zmienna znika). Gospodarz dopisuje do CSS: margines treści o szerokość Pomocy i przesunięcie własnej szuflady systemu w lewo (Pomoc stoi skrajnie z prawej). Margines dopisz do każdego elementu, który dziś odsuwa się o szerokość szuflady (w FIDmanie treść, ścieżka i stopka: `AppShell.tsx:40,46,64`):

```css
main { margin-right: calc(var(--preview-drawer-width, 0px) + var(--envi-pomoc-drawer-width, 0px)); }
[data-preview-drawer] { right: var(--envi-pomoc-drawer-width, 0px); } /* własna szuflada systemu; FIDman: PreviewDrawer.tsx */
```

Poniżej 900 px Pomoc zakrywa stronę, więc gospodarz pomija tam oba marginesy i nie pokazuje swojej szuflady pod spodem (`@media (max-width: 900px)`).

Zmienne gospodarza: `--envi-agent-*` jak wyżej, ale muszą być ustawione na `:root`/`body`, nie tylko na `.envi-agent-panel` (szuflada leży poza ramą panelu); czcionka i rozmiary idą z `font: inherit`. Stały podpis ENVI (kolory nagłówka, linii, tła) jest zaszyty i jednakowy w systemach. Do ustawienia: `--envi-pomoc-width` (domyślnie 440px), `--envi-pomoc-top` (np. wysokość paska) i `--envi-pomoc-z` (domyślnie 40). `--envi-pomoc-top` musi być ustawione tam, gdzie szuflada je widzi (na `:root`/`body`); FIDman trzyma `--app-menu-height` na elemencie AppShell, więc musi je przenieść albo wskazać wartość wprost. Skrót F1 i fokus po otwarciu należą do gospodarza.
